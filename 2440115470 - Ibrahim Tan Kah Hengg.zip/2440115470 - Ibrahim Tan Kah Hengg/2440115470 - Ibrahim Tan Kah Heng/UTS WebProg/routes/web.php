<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PublisherController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\DetailsController;

Route::get('/contact',[ContactController::class,'index'])->name('contact');
Route::get('/', [HomeController::class, 'index'])-> name('home');
Route::get('/publishers',[PublisherController::class,'index'])->name('publishers');
Route::get('/categories/{id}',[CategoryController::class,'index'])->name('categories');
Route::get('/details/{id}',[DetailsController::class,'index'])->name('details');