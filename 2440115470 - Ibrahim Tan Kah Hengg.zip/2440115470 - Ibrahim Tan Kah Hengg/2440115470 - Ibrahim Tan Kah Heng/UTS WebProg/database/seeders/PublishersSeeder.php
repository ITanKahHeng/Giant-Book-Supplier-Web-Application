<?php
namespace Database\Seeders;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PublishersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('publishers')->insert(
            [
                'name'=>'Kompas Gramedia',
                'address'=>'Jalan Garnet Barat 2',
                'phone'=>'081387881869',
                'email'=>'contact@kompasgramedia.com',
                'image'=>'images/publishers/csr-logo.png',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ]    
        );
        DB::table('publishers')->insert(
            [
                'name'=>'Grasindo',
                'address'=>'Jalan Garnet Barat 3',
                'phone'=>'085946171259',
                'email'=>'contact@grasindo.com',
                'image'=>'images/publishers/1393947016.png',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ]  
        );
    }
}