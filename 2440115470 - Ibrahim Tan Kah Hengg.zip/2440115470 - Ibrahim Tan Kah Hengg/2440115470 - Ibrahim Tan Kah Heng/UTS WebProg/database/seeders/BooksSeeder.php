<?php
namespace Database\Seeders;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BooksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert(
            [
                'publisher_id'=>'1',
                'title'=>'Harry Potter and The Sorcerers Stone',
                'author'=>'J.K Rowling',
                'year'=>'Juni 26, 1997',
                'synopsis'=>'Harry Potter bahkan belum pernah mendengar tentang Hogwarts ketika surat-surat mulai berjatuhan di keset pintu nomor empat, Privet Drive. Ditulis dengan tinta hijau di atas perkamen kekuningan dengan segel ungu, mereka dengan cepat disita oleh bibi dan pamannya yang mengerikan. Kemudian, pada hari ulang tahun Harry yang kesebelas, seorang pria raksasa bermata kumbang bernama Rubeus Hagrid datang dengan beberapa berita mencengangkan: Harry Potter adalah seorang penyihir, dan dia mendapat tempat di Sekolah Sihir dan Sihir Hogwarts. Petualangan luar biasa akan segera dimulai!',
                'image'=>'images/books/HP1.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ]
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'2',
                'title'=>'Harry Potter and the Chamber of Secrets',
                'author'=>'J.K Rowling',
                'year'=>'Juli 2, 1998',
                'synopsis'=>'Musim panas Harry Potter termasuk ulang tahun terburuk yang pernah ada, peringatan malapetaka dari peri rumah bernama Dobby, dan penyelamatan dari keluarga Dursley oleh temannya Ron Weasley dengan mobil terbang ajaib! Kembali ke Sekolah Sihir Hogwarts untuk tahun keduanya, Harry mendengar bisikan aneh bergema melalui koridor kosong - dan kemudian serangan dimulai. Siswa ditemukan seolah-olah berubah menjadi batu... Ramalan jahat Dobby tampaknya menjadi kenyataan.',
                'image'=>'images/books/HP2.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ] 
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'1',
                'title'=>'Harry Potter and the Prisoner of Azkaban',
                'author'=>'J.K Rowling',
                'year'=>'Juli 8, 1999',
                'synopsis'=>'Ketika Bus Ksatria menerobos kegelapan dan memekik berhenti di depannya, itu adalah awal dari tahun yang jauh dari biasa di Hogwarts untuk Harry Potter. Sirius Black, pembunuh massal yang melarikan diri dan pengikut Lord Voldemort, sedang dalam pelarian - dan mereka mengatakan dia mengejar Harry. Di kelas Ramalan pertamanya, Profesor Trelawney melihat pertanda kematian di daun teh Harry... Tapi mungkin yang paling menakutkan dari semuanya adalah Dementor yang berpatroli di halaman sekolah, dengan ciuman penghisap jiwa mereka...',
                'image'=>'images/books/HP3.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ]  
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'1',
                'title'=>'The Hunger Games: Hunger Games Trilogy, Part 1',
                'author'=>'Suzanne Collins',
                'year'=>'September 14, 2008',
                'synopsis'=>'Di reruntuhan tempat yang dulu dikenal sebagai Amerika Utara terdapat negara Panem, sebuah Capitol yang bersinar dikelilingi oleh dua belas distrik terpencil. Capitol menjaga agar distrik-distrik tetap sejalan dengan memaksa mereka semua untuk mengirim satu anak laki-laki dan satu perempuan antara usia dua belas dan delapan belas tahun untuk berpartisipasi dalam Hunger Games tahunan, pertarungan sampai mati di siaran langsung TV.',
                'image'=>'images/books/THG1.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ]  
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'1',
                'title'=>'The Hunger Games: Catching Fire, Hunger Games Trilogy, Part 2',
                'author'=>'Suzanne Collins',
                'year'=>'September 1, 2009',
                'synopsis'=>'Melawan segala rintangan, Katniss Everdeen telah memenangkan Hunger Games tahunan dengan sesama peserta distrik Peeta Mellark. Tapi itu adalah kemenangan yang dimenangkan dengan menentang Capitol dan aturan keras mereka. Katniss dan Peeta seharusnya senang Tapi ada desas-desus tentang pemberontakan di antara subjek, dan Katniss dan Peeta, yang membuat mereka takut adalah wajah dari pemberontakan itu. Capitol marah. Capitol ingin balas dendam.',
                'image'=>'images/books/THG2.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ] 
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'1',
                'title'=>'The Hunger Games: Mockingjay, Hunger Games Trilogy, Part 3)',
                'author'=>'Suzanne Collins',
                'year'=>'Agustus 24, 2010',
                'synopsis'=>'Capitol marah. Capitol ingin balas dendam. Menurut mereka siapa yang harus membayar kerusuhan itu? Katniss Everdeen. Buku terakhir dalam trilogi The Hunger Games oleh Suzanne Collins akan membuat jantung berdebar kencang, membalik halaman, dan semua orang berbicara tentang salah satu buku dan penulis terbesar dan paling banyak dibicarakan dalam sejarah penerbitan baru-baru ini!',
                'image'=>'images/books/THG3.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ] 
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'2',
                'title'=>'Fantastic Beasts: The Crimes of Grindelwald',
                'author'=>'J.K Rowling',
                'year'=>'November 16, 2018',
                'synopsis'=>'Dalam upaya untuk menggagalkan rencana jahat Grindelwald, Albus Dumbledore meminta bantuan Newt Scamander, mantan murid Hogwarts, yang setuju untuk membantu sekali lagi, tidak menyadari bahaya yang ada di depan. Garis ditarik saat cinta dan kesetiaan diuji, bahkan di antara teman dan keluarga yang paling sejati, di dunia sihir yang semakin terbagi.',
                'image'=>'images/books/COG.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ]  
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'2',
                'title'=>'To All The Boys ive Loved Before',
                'author'=>'Jenny Han',
                'year'=>'April 15, 2014',
                'synopsis'=>'Lara Jean yang berusia enam belas tahun menyimpan surat cintanya di kotak topi pemberian ibunya. ini adalah surat cinta yang dia tulis. Satu untuk setiap anak laki-laki yang pernah dia cintai - semuanya lima. Ketika dia menulis, dia mencurahkan hati dan jiwanya dan mengatakan semua hal yang tidak akan pernah dia katakan dalam kehidupan nyata. Sampai hari surat rahasianya dikirimkan, dan mendadak kehidupan cinta Lara Jean berubah dari imajiner menjadi di luar kendali.',
                'image'=>'images/books/TATB.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ] 
        );
        DB::table('books')->insert(
            [
                'publisher_id'=>'1',
                'title'=>'The Lord Of The Rings: One Volume',
                'author'=>'J.R.R. Tolkien',
                'year'=>'Februari 15, 2012',
                'synopsis'=>' Pada zaman kuno, Cincin Kekuatan dibuat oleh pandai besi Elf, dan Sauron, Pangeran Kegelapan, menempa Cincin Utama, mengisinya dengan kekuatannya sendiri sehingga dia bisa menguasai yang lainnya. Tapi Cincin Utama diambil darinya, dan meskipun dia mencarinya di seluruh Dunia Tengah, Cincin itu tetap hilang darinya. Setelah sekian lama, secara kebetulan jatuh ke tangan hobbit Bilbo Baggins.',
                'image'=>'images/books/LOTR.jpg',
                'created_at'=> Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at'=> Carbon::now()->format('Y-m-d H:i:s')
            ]           
        );
    }
}