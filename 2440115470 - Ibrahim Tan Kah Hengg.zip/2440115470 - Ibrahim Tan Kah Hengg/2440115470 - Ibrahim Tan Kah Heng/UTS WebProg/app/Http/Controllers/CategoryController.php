<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\categories;
use App\Models\books;
use Illuminate\Support\Facades\DB;
class CategoryController extends Controller
{
    public function index ($id){
        $categories = categories::all();
        $kategori=DB::table('categories')->select('categories.name')->where('categories.id','=',$id)->first();
        $category= DB::table('categories')->join('book_categories','categories.id','=','book_categories.category_id')
        ->join('books','book_categories.book_id','=','books.id')->select('books.*','categories.name')
        ->where('categories.id','=',$id)
        ->get();    return view('category',['categories'=>$categories,'kategori'=>$kategori],compact('category'));
    }
}