<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\categories;
class DetailsController extends Controller
{
    public function index($id){
        $categories = categories::all();
        $book = DB::table('books')->join('publishers','books.publisher_id','=','publishers.id')
        ->select('books.*','publishers.name as pName','books.image as images')
        ->where('books.id','=',$id)->first();
        return view('details',['book'=>$book,'categories'=>$categories]);
    }
}