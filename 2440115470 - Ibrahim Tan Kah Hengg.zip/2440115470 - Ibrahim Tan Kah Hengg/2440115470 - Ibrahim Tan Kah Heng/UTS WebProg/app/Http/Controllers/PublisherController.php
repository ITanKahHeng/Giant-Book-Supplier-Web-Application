<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\books;
use App\Models\categories;
use App\Models\publishers;

class PublisherController extends Controller
{
    public function index(){
        $books = books::all();  
        $categories = categories::all();
        $pub = publishers::all();
        return view('publishers',['categories'=>$categories,'pub'=>$pub,'books'=>$books]);
    }
}