<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class categories extends Model
{
    use HasFactory;
    public function bookCategory(){
        return $this->belongsTo(bookCategory::class);
    }
}