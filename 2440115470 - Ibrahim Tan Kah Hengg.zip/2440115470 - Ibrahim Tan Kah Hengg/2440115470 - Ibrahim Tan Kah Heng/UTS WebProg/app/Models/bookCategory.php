<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class bookCategory extends Model
{
    public function books(){
        return $this->belongsToMany(books::class);
    }
    public function categories(){
        return $this->hasMany(categories::class);
    }
    use HasFactory;
}