<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class books extends Model
{
    use HasFactory;
    public function bookCategory(){ return $this->hasMany(bookCategory::class);
    }
    public function publishers(){   return $this->hasOne(publishers::class);
    }
}