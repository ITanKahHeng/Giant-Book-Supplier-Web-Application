@extends('layout.mainlayout')
@section('content')

<div class="pt-4">
<div class="card container pt-1 bg-light">
    <div class="card-header bg-primary text-light row">
        <div class="col-12 col-md-6">
            <h1 class="text-white"> Contact  </h1>
        </div>
    </div>

    <div class="card-body row container">
        <div class="container rounded p-2 bg-light">
            <div class="row bg-light">
                <div class= "row pl-2">

                    <h2 class="text-primary">Store Address:</h2>
                    <p class="text-dark">

                        <br> Jalan Pembangunan Baru Raya, 
                        <br> Kompleks Pertokoan Emerald Blok III/12 
                        <br> Bintaro, Tangerang Selatan 
                        <br> Indonesia   
                    </p>
                </div>

                <div class= "row pl-2">
                    <h2 class="text-primary">Open Daily:</h2>
                    <p class="text-dark">

                       <br> 08.00-20.00

                    </p>
                </div>
                <div class= "row pl-2">
                    
                    <h2 class="text-primary">Contact :</h2>
                    <p class="text-dark">
                        <br> Phone : 021-08899776655
                        <br> Email : giantbooksupplier@happy.com 
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection