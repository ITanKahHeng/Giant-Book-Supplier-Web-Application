@section('content')
@extends('layout.mainlayout')

<div class="card container pt-1 bg-light">
    <div class="row bd-highlight pb-3 ">
        @foreach($books as $book)
            <div class="p-2 col-sm-4 bd-highlight pr-4 pb-4 ">
                <div class="card sm-12">
                    <img style="width:100px height:200px" class="img-fluid img-thumbnail card-img-top rounded" src="{{Storage::url($book->image)}}">
                    <div class="card-body">
                    <div class="pl-1">
                            <p class="card-title h5 text-primary">{{$book->title}}</p>
                            <p class="card-title text-info">by <b>{{$book->author}}</b></p>
                        </div>
                    <a href="{{route('details',['id'=>$book->id])}}" class="btn btn-outline-success">Details</a>
                    </div>
                </div>                                
            </div>
        @endforeach
    </div>
</div>
@endsection