            <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                <div class="container-fluid">
                    <a class="nav-link ms-sm-5 me-sm-5 text-light" href="{{route('home')}}">Giant Book Supplier</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarColor01">
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link active text-light" href="{{route('home')}}">Home</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Category</a>
                                    <div class="dropdown-menu">
                                    @foreach ($categories as $category)
                                        <a class="dropdown-item" href="{{route('categories',['id'=>$category->id])}}">{{$category->name}}</a>  
                                    @endforeach
                                    </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active text-light" href="{{route('publishers')}}">Publishers</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active text-light" href="{{route('contact')}}">Contact</a>
                            </li>
                        </ul>    
                    </div>
                </div>
            </nav>