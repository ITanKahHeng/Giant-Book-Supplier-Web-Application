<!DOCTYPE html>

<html lang="{{ str_replace('_', '-',app()->getLocale()) }}">
    <head>

        @include('layout.partials.head')
    </head>
    <body class ="antialiased">
        <header>

            @include('layout.partials.nav')
        </header>
        <div class="pb-3">
            
            @yield('content')
        </div>

        @include('layout.partials.footer')
    </body>
</html>