@extends('layout.mainlayout')
@section('content')

<div class="pt-4">
    <div class="card container pt-1 bg-light">
        <div class="card-header bg-primary text-light row">
            <div class="col-12 col-md-6">
    
                    <h1 class="text-white">{{$kategori->name}}</h1>    
            </div>
        </div>
        <div class="row bd-highlight pb-3 ">
            @foreach($category as $c)
                <div class="p-2 col-sm-4 bd-highlight pr-4 pb-4 ">
                    <div class="card sm-12">

                        <img style="width:100px height:200px" class="img-fluid img-thumbnail card-img-top rounded" src="{{Storage::url($c->image)}}">
                        <div class="card-body">
                        <div class="pl-1">
                            
                                <p class="card-title h5 text-primary">{{$c->title}}</p>
                                <p class="card-title text-info">by <b>{{$c->author}}</b></p>
                            </div>
                        <a href="{{route('details',['id'=>$c->id])}}" class="btn btn-outline-success">Details</a>
                        </div>
                    </div>      
                </div>
            @endforeach
        </div>      
    </div>
</div>
@endsection