@section('content')
@extends('layout.mainlayout')
<div class="pt-4">
    <div class="card container pt-1 bg-light">
        <div class="card-header bg-primary text-light row">
            <div class="col-12 col-md-6">
                    <h1 class="text-white">Book Details</h1>
            </div>
        </div>
        <div class="card-body row container">
            <div class="container rounded p-2 bg-light">
                <div class="row bg-light">
                    <div class="col-1 col-lg-3  ">
                            <img src="{{Storage::url($book->images)}}" width="100%"  class="rounded" />
                    </div>
                    <div class="col-8 col-md-8">
                        <div class="row pl-2">
                            <h4 class="text-dark">Title : {{$book->title}}</h4>
                        </div>
                        <div class="row pl-2">
                            <h4 class="text-dark">Author : {{$book->author}}</h4>
                        </div>
                        <div class="row pl-2">
                            <h4 class="text-dark">Publisher : {{$book->pName}}</h4>
                        </div>
                        <div class="row pl-2">
                            <h4 class="text-dark">Title : {{$book->year}}</h4>
                        </div>
                        <div class="row pl-2">
                            <p class="text-dark">Synopsis :<br> {{$book->synopsis}}</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection