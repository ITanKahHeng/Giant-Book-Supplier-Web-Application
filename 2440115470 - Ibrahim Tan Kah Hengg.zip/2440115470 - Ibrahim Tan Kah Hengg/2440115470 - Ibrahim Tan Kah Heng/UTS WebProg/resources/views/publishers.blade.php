@section('content')
@extends('layout.mainlayout')

<div class="pt-4">
    <div class="card container pt-1 bg-light">
        @foreach($pub as $p)
        


        <div class="card-header bg-white text-light row">


            <div class="col-10">

                <h1 class="text-black">{{$p->name}}</h1>
                
                <div class="row pl-2">
                    <h5 class="text-black">Address : {{$p->address}}</h5>
                </div>

                <div class="row pl-2">
                    <h5 class="text-black">Phone : {{$p->phone}}</h5>
                </div>
                
                <div class="row pl-2">
                    <h5 class="text-black">Email : {{$p->email}}</h5>
                </div>
                
            </div>
            <div class="col-2 ">
                    <img src="{{Storage::url($p->image)}}" width="100%"  class="rounded" />
                </div>
        </div>
        <div class="row bd-highlight pb-3 ">
            @foreach ( $books as $b )
                        @if ($p->id == $b->publisher_id)
                <div class="p-2 col-sm-4 bd-highlight pr-4 pb-4 ">
                    
                            <div class="card sm-12">

                                <img style="width:100px height:200px" class="img-fluid img-thumbnail card-img-top rounded" src="{{Storage::url($b->image)}}">
                                <div class="card-body">
                                <div class="pl-1">
                                    
                                        <p class="card-title h5 text-primary">{{$b->title}}</p>
                                        <p class="card-title text-info">by <b>{{$b->author}}</b></p>
                                    </div>

                                <a href="{{route('details',['id'=>$b->id])}}" class="btn btn-outline-success">Details</a>
                                </div>
                            </div>   
                </div>
                @endif 
                @endforeach
        </div>
        @endforeach
    </div>
</div> @endsection