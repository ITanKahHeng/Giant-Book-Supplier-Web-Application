
<?php $__env->startSection('content'); ?>
<div class="pt-4">
    <div class="card container pt-1 bg-light">
        <div class="card-header bg-primary text-light row">
            <div class="col-12 col-md-6">
    
                    <h1 class="text-white"><?php echo e($kategori->name); ?></h1>
                
                
            </div>
        </div>
        <div class="row bd-highlight pb-3 ">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-2 col-sm-4 bd-highlight pr-4 pb-4 ">
                    <div class="card sm-12">
                        <img style="width:100px height:200px" class="img-fluid img-thumbnail card-img-top rounded" src="<?php echo e(Storage::url($c->image)); ?>">
                        <div class="card-body">
                        <div class="pl-1">
                                <p class="card-title h5 text-primary"><?php echo e($c->title); ?></p>
                                <p class="card-title text-info">by <b><?php echo e($c->author); ?></b></p>
                            </div>
                        <a href="<?php echo e(route('details',['id'=>$c->id])); ?>" class="btn btn-outline-success">Details</a>
                        </div>
                    </div>
                    
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php 
/**PATH C:\Binus\semester 5\web prog\UTS\resources\views/category.blade.php ENDPATH**/ ?>