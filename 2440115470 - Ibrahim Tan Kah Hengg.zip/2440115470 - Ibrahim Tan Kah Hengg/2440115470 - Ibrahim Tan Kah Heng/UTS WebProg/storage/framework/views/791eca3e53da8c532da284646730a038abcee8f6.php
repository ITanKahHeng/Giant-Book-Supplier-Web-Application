<?php $__env->startSection('content'); ?>


<div class="card container pt-1 bg-light">
    <div class="row bd-highlight pb-3 ">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-2 col-sm-4 bd-highlight pr-4 pb-4 ">
                <div class="card sm-12">
                    <img style="width:100px height:200px" class="img-fluid img-thumbnail card-img-top rounded" src="<?php echo e(Storage::url($book->image)); ?>">
                    <div class="card-body">
                    <div class="pl-1">
                            <p class="card-title h5 text-primary"><?php echo e($book->title); ?></p>
                            <p class="card-title text-info">by <b><?php echo e($book->author); ?></b></p>
                        </div>
                    <a href="<?php echo e(route('details',['id'=>$book->id])); ?>" class="btn btn-outline-success">Details</a>
                    </div>
                </div>                                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\ITKH\ITKH\UTS WebProg\resources\views/home.blade.php ENDPATH**/ ?>