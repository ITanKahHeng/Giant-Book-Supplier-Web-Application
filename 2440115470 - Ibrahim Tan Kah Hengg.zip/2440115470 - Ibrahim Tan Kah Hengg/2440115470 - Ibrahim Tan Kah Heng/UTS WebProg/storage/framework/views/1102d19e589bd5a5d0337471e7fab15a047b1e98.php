<?php $__env->startSection('content'); ?>


<div class="pt-4">
    <div class="card container pt-1 bg-light">
        <?php $__currentLoopData = $pub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        


        <div class="card-header bg-white text-light row">


            <div class="col-10">

                <h1 class="text-black"><?php echo e($p->name); ?></h1>
                
                <div class="row pl-2">
                    <h5 class="text-black">Address : <?php echo e($p->address); ?></h5>
                </div>

                <div class="row pl-2">
                    <h5 class="text-black">Phone : <?php echo e($p->phone); ?></h5>
                </div>
                
                <div class="row pl-2">
                    <h5 class="text-black">Email : <?php echo e($p->email); ?></h5>
                </div>
                
            </div>
            <div class="col-2 ">
                    <img src="<?php echo e(Storage::url($p->image)); ?>" width="100%"  class="rounded" />
                </div>
        </div>
        <div class="row bd-highlight pb-3 ">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->id == $b->publisher_id): ?>
                <div class="p-2 col-sm-4 bd-highlight pr-4 pb-4 ">
                    
                            <div class="card sm-12">

                                <img style="width:100px height:200px" class="img-fluid img-thumbnail card-img-top rounded" src="<?php echo e(Storage::url($b->image)); ?>">
                                <div class="card-body">
                                <div class="pl-1">
                                    
                                        <p class="card-title h5 text-primary"><?php echo e($b->title); ?></p>
                                        <p class="card-title text-info">by <b><?php echo e($b->author); ?></b></p>
                                    </div>

                                <a href="<?php echo e(route('details',['id'=>$b->id])); ?>" class="btn btn-outline-success">Details</a>
                                </div>
                            </div>   
                </div>
                <?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\ITKH\ITKH\UTS WebProg\resources\views/publishers.blade.php ENDPATH**/ ?>