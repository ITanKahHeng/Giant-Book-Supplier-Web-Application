<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Giant Book Supplier</title>

        <!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">      
        

        <!-- Styles -->
<!--<link  href ="https://bootswatch.com/5/lux/bootstrap.min.css"  rel ="stylesheet">-->
<link href="<?php echo e(asset('css/theme.css')); ?>" rel="stylesheet"><?php /**PATH C:\Binus\semester 5\web prog\UTS\resources\views/layout/partials/head.blade.php ENDPATH**/ ?>