<footer class="section footer text-light bg-primary ">
        <div class="text-center">
            Gian Book Supplier - 2022 // Ibrahim Tan Kah Heng - 2440115470
        </div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script><?php /**PATH C:\Users\User\Downloads\UTS WebProg\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>